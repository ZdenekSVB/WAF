<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div id="app">
    <main>
      <RouterView />
    </main>
  </div>
</template>

<!-- jestli ještě někdo tady bude stylovat všechny obrazovky utrhnu mu ruce -->
<style scoped>

</style>
