<template>
    <div>
      <h1>CS</h1>
    </div>
  </template>
  
  <script lang="ts">
  import { defineComponent } from 'vue';
  
  export default defineComponent({
    name: 'CSView'
  });
  </script>
  