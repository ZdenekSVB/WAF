<template>

<v-app>

<AppBar/>

<v-main>

<p>Champs</p>

</v-main>







</v-app>






</template>

<script lang="ts">





</script>