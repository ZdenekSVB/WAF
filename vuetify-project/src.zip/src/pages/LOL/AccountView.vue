<template>

    <v-app>
    
    <AppBar/>
    
    <v-main>
    
    <p>Account</p>
    
    </v-main>
    
    
    
    
    
    
    
    </v-app>
    
    
    
    
    
    
    </template>
    
    <script lang="ts">
    
    
    
    
    
    </script>